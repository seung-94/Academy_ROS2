#include <iostream>

int main()
{
    std::cout << "aaaa" << std::endl;
    return 0;
}