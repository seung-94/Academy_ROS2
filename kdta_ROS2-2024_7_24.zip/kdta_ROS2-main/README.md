# kdta_ROS2

- 공유 슬라이드
[링크](https://docs.google.com/presentation/d/1453nx14DVMk0nBLW7jpt0g6x7a7z2wuNaJKmcVQi4rw/edit?usp=sharing)

---

## 2024-07-23

---

- 1 차시
  - vmware 설치
  - ubuntu 22.04 설치
  - terminator 설치
  - git 설치
- 2 차시
  - vscode 설치
  - github 연동
- 3 차시
